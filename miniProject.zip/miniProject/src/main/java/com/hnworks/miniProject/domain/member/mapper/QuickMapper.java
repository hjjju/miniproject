package com.hnworks.miniProject.domain.member.mapper;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface QuickMapper {
}
